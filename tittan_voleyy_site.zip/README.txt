Tittan voleyy club - Site (static)
Arquivos nesta pasta:
- index.html
- coaches.html
- apply.html
- approved.html
- styles.css
- script.js

Como usar:
1) Baixe o arquivo zip e descompacte.
2) Para testar localmente, abra index.html no navegador.
3) Para hospedar online (grátis):
   - GitHub Pages: crie repo, faça commit dos arquivos e ative Pages na branch main (docs).
   - Netlify: arraste a pasta ou faça deploy com Git.
   - Replit: crie um Repl estático e envie os arquivos.
Formulário de inscrição salva localmente no navegador e gera arquivo JSON para download.
