// Simple client-side interactions: save form to JSON, create downloadable file, show simple profile modal
function saveJSON(data, filename) {
  const blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
  const url = URL.createObjectURL(blob);
  return url;
}

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('coachForm');
  if(form){
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      const data = {};
      fd.forEach((v,k) => data[k]=v);
      data.submittedAt = new Date().toISOString();
      // save to localStorage
      const key = 'titan_coach_'+(data.discord||Date.now());
      localStorage.setItem(key, JSON.stringify(data));
      // create downloadable file
      const url = saveJSON(data, 'cadastro_coach.json');
      const dl = document.getElementById('downloadLink');
      dl.href = url;
      dl.download = (data.nome || 'cadastro') + '.json';
      document.getElementById('confirm').classList.remove('hidden');
      // scroll to confirmation
      document.getElementById('confirm').scrollIntoView({behavior:'smooth'});
    });
  }
});

function saveDraft(){
  const form = document.getElementById('coachForm');
  if(!form) return;
  const fd = new FormData(form);
  const data = {};
  fd.forEach((v,k) => data[k]=v);
  localStorage.setItem('titan_draft', JSON.stringify(data));
  alert('Rascunho salvo no navegador!');
}

function openProfile(name, specialty, exp){
  alert(name + '\\n' + specialty + '\\nExperiência: ' + exp + '\\n\\nTeste prático: contate Gabriel no Discord para agendar.');
}
